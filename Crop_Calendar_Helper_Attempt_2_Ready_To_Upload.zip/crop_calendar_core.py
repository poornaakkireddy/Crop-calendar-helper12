"""Domain model and rules for Crop Calendar Helper, independent of terminal UI."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import date

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
TASK_TYPES = ["Sowing", "Care", "Irrigation", "Fertilizing",
              "Weeding", "Pest Control", "Harvest"]
STATUSES = ["Pending", "Done"]
MAX_CROP, MAX_NOTES = 40, 200


@dataclass
class Task:
    id: int
    crop: str
    task_type: str
    month: int
    status: str = "Pending"
    notes: str = ""


def parse_month(text: str) -> int | None:
    text = str(text).strip().lower()
    if text.isdigit() and 1 <= int(text) <= 12:
        return int(text)
    for index, name in enumerate(MONTHS, 1):
        if text[:3] == name.lower() and len(text) >= 3:
            return index
    return None


def validate_fields(crop, task_type, month, status, notes) -> tuple[dict | None, str]:
    """Return normalized task fields or a readable validation error."""
    crop = str(crop).strip()
    if not crop:
        return None, "crop name is blank"
    if len(crop) > MAX_CROP:
        return None, f"crop name longer than {MAX_CROP} characters"
    if not all(ch.isalnum() or ch in " -'." for ch in crop):
        return None, "crop name has invalid characters"
    normalized_type = next(
        (item for item in TASK_TYPES if item.lower() == str(task_type).strip().lower()), None
    )
    if normalized_type is None:
        return None, f"task type must be one of {', '.join(TASK_TYPES)}"
    parsed_month = parse_month(month)
    if parsed_month is None:
        return None, "month must be 1-12 or a month name"
    normalized_status = next(
        (item for item in STATUSES if item.lower() == str(status).strip().lower()), None
    )
    if normalized_status is None:
        return None, f"status must be one of {', '.join(STATUSES)}"
    notes = str(notes).strip()
    if len(notes) > MAX_NOTES:
        return None, f"notes longer than {MAX_NOTES} characters"
    return {
        "crop": crop.title(), "task_type": normalized_type, "month": parsed_month,
        "status": normalized_status, "notes": notes,
    }, ""


def is_overdue(task: Task, current_month: int | None = None) -> bool:
    """Return whether a pending task's month has passed in the current year."""
    month = current_month or date.today().month
    return task.status == "Pending" and task.month < month


def compute_summary(tasks: list[Task], current_month: int | None = None) -> dict:
    """Calculate reusable summary metrics without terminal or HTML formatting."""
    total = len(tasks)
    done = sum(task.status == "Done" for task in tasks)
    by_month = Counter(task.month for task in tasks)
    active_months = len(by_month)
    return {
        "total": total,
        "done": done,
        "pending": total - done,
        "completion_pct": round(100 * done / total, 1) if total else 0.0,
        "overdue": sum(is_overdue(task, current_month) for task in tasks),
        "crops": len({task.crop for task in tasks}),
        "by_type": Counter(task.task_type for task in tasks),
        "by_month": by_month,
        "avg_per_active_month": round(total / active_months, 1) if active_months else 0.0,
        "busiest": by_month.most_common(1)[0] if by_month else None,
    }
