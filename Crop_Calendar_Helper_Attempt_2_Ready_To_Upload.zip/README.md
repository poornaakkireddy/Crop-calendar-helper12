# Crop Calendar Helper

A standard-library Python app for planning crop activities by month. It includes a terminal manager and a protected, read-only web dashboard. Data is stored in SQLite.

## Features

- Add, browse, search, complete, and remove crop tasks
- See a year-round calendar, completion summary, and overdue reminders
- Import CSV and export CSV, text, and Markdown reports
- Filter dashboard tasks by crop, month, task type, or status
- Preserve data with SQLite transactions, WAL mode, indexed month queries, and stale-edit conflict checks
- Import older `crop_tasks.json` data once when the SQLite database is first created
- Validate task input and record operational errors in log files

## Requirements and launch

Python 3.10 or newer is required. No third-party packages are used.

Start the terminal app:

```console
python crop_calendar_helper.py
```

To start the web dashboard in another terminal:

```console
python web_view.py
```

Open the address printed by the dashboard. The first launch prints a random temporary password. The dashboard is read-only; make changes in the terminal app. It binds to `127.0.0.1` by default. Keep it on the local computer unless you place it behind an HTTPS server.

## Configuration

Copy `crop_calendar.ini.example` to `crop_calendar.ini` and edit the values you need. The real config file is ignored by Git. Leave the password blank to generate a new random password each time the dashboard starts. Set a fixed password in the local config or use environment variables such as `CROP_CALENDAR_WEB_USERNAME`, `CROP_CALENDAR_WEB_PASSWORD`, `CROP_CALENDAR_WEB_HOST`, and `CROP_CALENDAR_WEB_PORT`.

Database, log, export, sample data, SQLite wait timeout, and CLI page size can also be set in the `[storage]` section or with `CROP_CALENDAR_*` environment variables. Invalid timeout, page-size, or port values stop startup with a clear configuration error.

## Tests

Run the automated regression suite:

```console
python -m unittest discover -v
```

Coverage includes validation limits, summary calculations, overdue boundaries, SQLite round trips, legacy-data migration, concurrent edits, and web login checks.

## Project layout

- `crop_calendar_core.py` - domain model, validation, overdue rules, and summary calculations
- `crop_calendar_helper.py` - terminal interface, CSV import, and report export
- `crop_calendar_store.py` - SQLite data-access layer, migration, transactions, and conflict handling
- `config.py` - centralized settings with INI and environment-variable support
- `web_view.py` - authenticated, read-only dashboard with responsive layout and client-side filters
- `test_crop_calendar_helper.py` - regression tests
- `crop_calendar.ini.example` - safe starter configuration
- `sample_tasks.json` / `sample_tasks.csv` - sample records; the CSV includes invalid rows for import demos
- `pyproject.toml` - project metadata and Python version

Runtime files are created beside the scripts: `crop_tasks.db`, `crop_calendar.log`, and (when needed) `import_errors.log`. Exports are written to `exports/`.

## Quick demo

1. Start the terminal app and select **10** to load sample data.
2. Select **3** to view the calendar, **7** for summary and warnings, or **8** to export reports.
3. Start `web_view.py` in another terminal and sign in with the username and password shown at launch.
4. Search tasks or filter by month and status in the dashboard.
