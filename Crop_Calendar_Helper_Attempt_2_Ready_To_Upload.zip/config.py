"""Central application settings with INI and environment-variable overrides."""
from __future__ import annotations

import configparser
import os
import secrets
from dataclasses import dataclass
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "crop_calendar.ini"
_parser = configparser.ConfigParser()
_parser.read(CONFIG_FILE, encoding="utf-8")


def _value(section: str, key: str, env_name: str, default: str) -> str:
    return os.environ.get(env_name, _parser.get(section, key, fallback=default)).strip()


def _path(section: str, key: str, env_name: str, default: str) -> str:
    value = Path(_value(section, key, env_name, default)).expanduser()
    return str(value if value.is_absolute() else BASE_DIR / value)


@dataclass(frozen=True)
class AppConfig:
    data_file: str
    legacy_data_file: str
    log_file: str
    export_dir: str
    sample_json: str
    sample_csv: str
    import_log: str
    db_timeout_seconds: int
    page_size: int
    web_host: str
    web_port: int
    web_username: str
    web_password: str
    generated_web_password: bool


def load_config() -> AppConfig:
    """Load settings from crop_calendar.ini, then apply CROP_CALENDAR_* overrides."""
    timeout = int(_value("storage", "busy_timeout_seconds", "CROP_CALENDAR_DB_TIMEOUT", "10"))
    page_size = int(_value("storage", "page_size", "CROP_CALENDAR_PAGE_SIZE", "10"))
    web_port = int(_value("web", "port", "CROP_CALENDAR_WEB_PORT", "8000"))
    if timeout < 1 or not 1 <= page_size <= 500 or not 1 <= web_port <= 65535:
        raise ValueError("Invalid settings: timeout must be positive, page_size 1-500, port 1-65535")

    username = _value("web", "username", "CROP_CALENDAR_WEB_USERNAME", "crop-user")
    configured_password = _value("web", "password", "CROP_CALENDAR_WEB_PASSWORD", "")
    generated = not configured_password
    password = configured_password or secrets.token_urlsafe(18)
    if not username or ":" in username:
        raise ValueError("Web username must be nonblank and cannot contain a colon")

    return AppConfig(
        data_file=_path("storage", "database", "CROP_CALENDAR_DB", "crop_tasks.db"),
        legacy_data_file=_path("storage", "legacy_json", "CROP_CALENDAR_LEGACY_JSON", "crop_tasks.json"),
        log_file=_path("storage", "log_file", "CROP_CALENDAR_LOG", "crop_calendar.log"),
        export_dir=_path("storage", "export_dir", "CROP_CALENDAR_EXPORT_DIR", "exports"),
        sample_json=_path("storage", "sample_json", "CROP_CALENDAR_SAMPLE_JSON", "sample_tasks.json"),
        sample_csv=_path("storage", "sample_csv", "CROP_CALENDAR_SAMPLE_CSV", "sample_tasks.csv"),
        import_log=_path("storage", "import_log", "CROP_CALENDAR_IMPORT_LOG", "import_errors.log"),
        db_timeout_seconds=timeout,
        page_size=page_size,
        web_host=_value("web", "host", "CROP_CALENDAR_WEB_HOST", "127.0.0.1"),
        web_port=web_port,
        web_username=username,
        web_password=password,
        generated_web_password=generated,
    )


CONFIG = load_config()
