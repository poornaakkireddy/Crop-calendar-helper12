"""Password-protected, read-only local dashboard for crop task data."""
from __future__ import annotations

import base64
import hmac
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer

from config import CONFIG
from crop_calendar_core import MONTHS, TASK_TYPES, compute_summary, is_overdue
from crop_calendar_helper import load_tasks


CSS = """
:root{color-scheme:light;--green:#176b45;--leaf:#e8f5ec;--ink:#20332a;--muted:#5d7065;--line:#dce6df}
*{box-sizing:border-box}body{font:16px/1.5 system-ui,sans-serif;color:var(--ink);max-width:1100px;margin:0 auto;padding:24px}
h1{margin:.2rem 0;color:var(--green)}h2{margin:1.8rem 0 .7rem}.sub{color:var(--muted);margin-top:0}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}.card{background:var(--leaf);border:1px solid var(--line);border-radius:12px;padding:16px}
.value{font-size:1.6rem;font-weight:700;color:var(--green)}.filters{display:flex;gap:10px;flex-wrap:wrap;margin:12px 0}
input,select{font:inherit;padding:9px 11px;border:1px solid #9aada0;border-radius:8px;background:white;color:var(--ink)}
input{flex:1;min-width:220px}table{border-collapse:collapse;width:100%;margin-bottom:1rem}th,td{border-bottom:1px solid var(--line);padding:10px;text-align:left}
th{background:#f3f8f4;color:var(--green)}.Done{color:#176b45;font-weight:650}.Pending{color:#96620c}.Overdue{color:#a22c2c;font-weight:700}
.progress{height:10px;background:#dce6df;border-radius:10px;overflow:hidden;margin:8px 0 2px}.progress span{display:block;height:100%;background:#22965d}
.empty{padding:20px;text-align:center;color:var(--muted)}footer{margin-top:24px;color:var(--muted);font-size:.9rem}
@media(max-width:600px){body{padding:14px}table{font-size:.9rem}th,td{padding:7px 5px}.notes{display:none}}
"""

SCRIPT = """
const search=document.querySelector('#search'),month=document.querySelector('#month'),task=document.querySelector('#task'),status=document.querySelector('#status');
function filterRows(){let shown=0;for(const row of document.querySelectorAll('#tasks tbody tr')){
 const okText=row.dataset.search.includes(search.value.trim().toLowerCase());
 const okMonth=!month.value||row.dataset.month===month.value;
 const okTask=!task.value||row.dataset.type===task.value;
 const okStatus=!status.value||row.dataset.status===status.value;
 row.hidden=!(okText&&okMonth&&okTask&&okStatus);if(!row.hidden)shown++;
 }document.querySelector('#empty').hidden=shown!==0;}
for(const control of [search,month,task,status])control.addEventListener('input',filterRows);
"""


def authorization_ok(header: str | None, username: str | None = None,
                     password: str | None = None) -> bool:
    """Check an HTTP Basic Authorization header without logging credentials."""
    username = CONFIG.web_username if username is None else username
    password = CONFIG.web_password if password is None else password
    raw = f"{username}:{password}".encode("utf-8")
    expected = "Basic " + base64.b64encode(raw).decode("ascii")
    return bool(header) and hmac.compare_digest(header, expected)


def page() -> str:
    tasks = load_tasks()
    summary = compute_summary(tasks)
    cards = [
        ("Tasks", summary["total"]),
        ("Crops", summary["crops"]),
        ("Completed", f"{summary['done']} ({summary['completion_pct']}%)"),
        ("Overdue", summary["overdue"]),
    ]
    card_html = "".join(
        f"<article class='card'><div>{escape(str(label))}</div><div class='value'>{escape(str(value))}</div></article>"
        for label, value in cards
    )
    progress = summary["completion_pct"]
    rows = []
    for task in sorted(tasks, key=lambda item: (item.month, item.crop, item.id)):
        state = "Overdue" if is_overdue(task) else task.status
        searchable = escape(f"{task.crop} {task.task_type} {task.notes}".lower(), quote=True)
        rows.append(
            f"<tr data-search='{searchable}' data-month='{task.month}' data-type='{escape(task.task_type, quote=True)}' data-status='{escape(state)}'>"
            f"<td>{MONTHS[task.month - 1]}</td><td>{escape(task.crop)}</td>"
            f"<td>{escape(task.task_type)}</td><td class='{escape(state)}'>{escape(state)}</td>"
            f"<td class='notes'>{escape(task.notes)}</td></tr>"
        )
    month_options = "".join(
        f"<option value='{index}'>{name}</option>" for index, name in enumerate(MONTHS, 1)
    )
    task_options = "".join(
        f"<option>{escape(task_type)}</option>" for task_type in TASK_TYPES
    )
    row_html = "".join(rows) or "<tr><td colspan='5' class='empty'>No crop tasks yet. Add tasks in the terminal app.</td></tr>"
    return (
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>Crop Calendar Helper</title><style>" + CSS + "</style></head><body>"
        "<header><h1>Crop Calendar Helper</h1><p class='sub'>A seasonal overview of your crop tasks.</p></header>"
        f"<section class='cards' aria-label='Task summary'>{card_html}</section>"
        f"<div class='progress' role='progressbar' aria-label='Task completion' aria-valuemin='0' aria-valuemax='100' aria-valuenow='{progress}'><span style='width:{progress}%'></span></div>"
        f"<p class='sub'>{progress}% of tasks completed</p>"
        "<h2>Crop tasks</h2><div class='filters'>"
        "<input id='search' type='search' placeholder='Search crop, task, or notes' aria-label='Search tasks'>"
        f"<select id='month' aria-label='Filter by month'><option value=''>All months</option>{month_options}</select>"
        f"<select id='task' aria-label='Filter by task type'><option value=''>All task types</option>{task_options}</select>"
        "<select id='status' aria-label='Filter by status'><option value=''>All statuses</option>"
        "<option>Pending</option><option>Done</option><option>Overdue</option></select></div>"
        "<table id='tasks'><thead><tr><th>Month</th><th>Crop</th><th>Task</th>"
        f"<th>Status</th><th class='notes'>Notes</th></tr></thead><tbody>{row_html}</tbody></table>"
        "<p id='empty' class='empty' hidden>No tasks match these filters.</p>"
        "<footer>Read-only local dashboard. Edit tasks in the terminal app.</footer>"
        f"<script>{SCRIPT}</script></body></html>"
    )


class Handler(BaseHTTPRequestHandler):
    server_version = "CropCalendar/2"
    sys_version = ""

    def _security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")

    def do_GET(self) -> None:
        if not authorization_ok(self.headers.get("Authorization")):
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Crop Calendar", charset="UTF-8"')
            self._security_headers()
            self.end_headers()
            return
        if self.path != "/":
            self.send_error(404, "Not found")
            return
        body = page().encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._security_headers()
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args) -> None:
        # Avoid logging Basic auth data while keeping useful request diagnostics.
        super().log_message(format, *args)


if __name__ == "__main__":
    print(f"Crop Calendar dashboard: http://{CONFIG.web_host}:{CONFIG.web_port}/")
    print(f"Username: {CONFIG.web_username}")
    if CONFIG.generated_web_password:
        print(f"Temporary password for this launch: {CONFIG.web_password}")
    else:
        print("Password: supplied via configuration")
    print("Dashboard is read-only. Use crop_calendar_helper.py to edit tasks.")
    HTTPServer((CONFIG.web_host, CONFIG.web_port), Handler).serve_forever()
