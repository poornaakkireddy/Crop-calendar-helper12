"""SQLite repository: persistence and legacy migration, separated from UI code."""
from __future__ import annotations

import json
import logging
import os
import sqlite3
from contextlib import contextmanager
from typing import Iterator

from crop_calendar_core import Task, validate_fields

logger = logging.getLogger("crop_calendar.store")


class TaskRepository:
    """Own database connections, migration, transactions, and conflict handling."""

    def __init__(self, database_path: str, legacy_json_path: str, timeout_seconds: int = 10):
        self.database_path = database_path
        self.legacy_json_path = legacy_json_path
        self.timeout_seconds = timeout_seconds
        self.last_snapshot: dict[int, Task] | None = None

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        os.makedirs(os.path.dirname(os.path.abspath(self.database_path)), exist_ok=True)
        conn = sqlite3.connect(self.database_path, timeout=self.timeout_seconds)
        try:
            conn.execute(f"PRAGMA busy_timeout={self.timeout_seconds * 1000}")
            conn.execute("PRAGMA journal_mode=WAL")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    @staticmethod
    def _ensure_schema(conn: sqlite3.Connection) -> None:
        conn.execute("""CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY, crop TEXT NOT NULL, task_type TEXT NOT NULL,
            month INTEGER NOT NULL, status TEXT NOT NULL, notes TEXT NOT NULL)""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_month ON tasks(month)")

    @staticmethod
    def _replace_tasks(conn: sqlite3.Connection, tasks: list[Task]) -> None:
        conn.execute("DELETE FROM tasks")
        conn.executemany(
            "INSERT INTO tasks(id,crop,task_type,month,status,notes) VALUES(?,?,?,?,?,?)",
            [(task.id, task.crop, task.task_type, task.month, task.status, task.notes)
             for task in tasks],
        )

    def load_tasks(self) -> list[Task]:
        """Read the database and migrate valid legacy JSON records once."""
        with self._connect() as conn:
            self._ensure_schema(conn)
            count = conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
            if count == 0 and os.path.exists(self.legacy_json_path):
                self._migrate_legacy_json(conn)
            rows = conn.execute(
                "SELECT id,crop,task_type,month,status,notes FROM tasks ORDER BY id"
            ).fetchall()
        tasks = [Task(*row) for row in rows]
        self.last_snapshot = {task.id: task for task in tasks}
        return tasks

    def _migrate_legacy_json(self, conn: sqlite3.Connection) -> None:
        try:
            with open(self.legacy_json_path, encoding="utf-8") as stream:
                raw = json.load(stream)
            if not isinstance(raw, list):
                raise ValueError("expected a JSON list")
            imported, skipped = [], 0
            for item in raw:
                try:
                    clean, error = validate_fields(
                        item["crop"], item["task_type"], item["month"],
                        item.get("status", "Pending"), item.get("notes", ""),
                    )
                    if error:
                        raise ValueError(error)
                    imported.append(Task(id=int(item["id"]), **clean))
                except (KeyError, TypeError, ValueError):
                    skipped += 1
            self._replace_tasks(conn, imported)
            logger.info("Migrated %d tasks from legacy JSON; skipped %d", len(imported), skipped)
            if skipped:
                logger.warning("Skipped %d invalid records during JSON migration", skipped)
        except (OSError, json.JSONDecodeError, UnicodeDecodeError, ValueError):
            logger.exception("Could not migrate legacy JSON data")
            raise RuntimeError(f"Could not read legacy data file: {self.legacy_json_path}")

    def save_tasks(self, tasks: list[Task]) -> None:
        """Persist a task snapshot and merge safe additions from other sessions."""
        with self._connect() as conn:
            self._ensure_schema(conn)
            current = {
                row[0]: Task(*row)
                for row in conn.execute(
                    "SELECT id,crop,task_type,month,status,notes FROM tasks"
                ).fetchall()
            }
            desired = {task.id: task for task in tasks}
            baseline = self.last_snapshot
            if baseline is None:
                self._replace_tasks(conn, tasks)
                merged = desired
            else:
                deleted = set(baseline) - set(desired)
                changed = {
                    task_id for task_id, task in desired.items()
                    if baseline.get(task_id) != task
                }
                for task_id in deleted | changed:
                    if current.get(task_id) != baseline.get(task_id):
                        logger.warning("Concurrent edit conflict for task id %d", task_id)
                        raise RuntimeError(
                            f"Task {task_id} changed in another session. Reload the app and retry."
                        )
                for task_id in changed:
                    if task_id not in baseline and task_id in current:
                        raise RuntimeError(
                            f"Task id {task_id} was added in another session. Reload the app and retry."
                        )
                conn.executemany("DELETE FROM tasks WHERE id=?", [(task_id,) for task_id in deleted])
                conn.executemany(
                    """INSERT INTO tasks(id,crop,task_type,month,status,notes)
                    VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET crop=excluded.crop,
                    task_type=excluded.task_type, month=excluded.month, status=excluded.status,
                    notes=excluded.notes""",
                    [(task.id, task.crop, task.task_type, task.month, task.status, task.notes)
                     for task in (desired[index] for index in changed)],
                )
                merged = current.copy()
                for task_id in deleted:
                    merged.pop(task_id, None)
                merged.update({task_id: desired[task_id] for task_id in changed})
                tasks[:] = sorted(merged.values(), key=lambda task: task.id)
            self.last_snapshot = merged.copy()
